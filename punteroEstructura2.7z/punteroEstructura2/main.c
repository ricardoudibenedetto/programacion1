#include <stdio.h>
#include <stdlib.h>
typedef struct {
char nombre[20];
int edad;
}ePersona;

void mostrarCadena(char* punteroCadena);
char* getCharX(void);

int main()
{
    int i;
    ePersona pers[3];
    ePersona *ptrPers;
    ptrPers=pers;
    for(i=0;i<3;i++)
    {

       printf("ingrese un nombnre : ");
       fflush(stdin);
       //gets(ptrPers[i].nombre);
       scanf("%s", (*(ptrPers+i)).nombre);
       printf("ingrese una edad  : ");
       fflush(stdin);
       scanf("%d", &(*(ptrPers+i)).edad);

    }
    for(i=0;i<3;i++)
    {
        printf("nombre : %s \t edad: %d\n", (*(ptrPers+i)).nombre, (*(ptrPers+i)).edad);
    }





    return 0;
}


void mostrarCadena(char* punteroCadena)
{
while(*punteroCadena != '\0')
{
printf("%c",*punteroCadena);

punteroCadena++;
}
}

char* getCharX(void)
{
    char letra[]="abc";
    return letra;
}

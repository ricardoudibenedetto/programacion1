#include <stdio.h>
#include <stdlib.h>
struct alumno {
char nombre[20];
int nota;
};
void mostrarCadena(char* punteroCadena);
char* getCharX(void);

int main()
{

    struct alumno auxiliarAlumno;
    struct alumno *punteroAlumno;
    punteroAlumno = &auxiliarAlumno;
    printf("ingrese un nombre : ");
    fflush(stdin);
   // scanf("%s", &punteroAlumno->nombre);
    scanf("%s", (*punteroAlumno).nombre);
   // *(punteroAlumno).nombre ;//es igual que punteroAlumno->nombre
    printf("\ningrese una nota : ");
     fflush(stdin);
    //scanf("%d", &punteroAlumno->nota);
    scanf("%d", &(*punteroAlumno).nota);

    printf("su nombre es %s y su nota %d", punteroAlumno->nombre, punteroAlumno->nota  );



    return 0;
}


void mostrarCadena(char* punteroCadena)
{
while(*punteroCadena != '\0')
{
printf("%c",*punteroCadena);

punteroCadena++;
}
}

char* getCharX(void)
{
    char letra[]="abc";
    return letra;
}

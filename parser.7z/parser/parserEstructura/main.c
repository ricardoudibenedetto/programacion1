#include <stdio.h>
#include <stdlib.h>
typedef struct
{
    int id;
    char marca[20];
    char modelo[20];
    char color[20];
    int anio;
    int estado;
} eAuto;
int main()
{
    eAuto* auto1;
    eAuto* auto1Aux;
    int i=0;
    int cant;
    FILE* f;
    char marca[20];
    char modelo[20];
    char color[20];
    int anio;
    int id;
    int tam=20;
    auto1= (eAuto*) malloc(tam*sizeof(eAuto));
    if(auto1==NULL)
    {
        printf("no hay espacio para cargar ");
    }
    else
    {
        //abrimos el puntero a file en mido de lectura r
        f=fopen("MOCK_DATA.csv","r");
        //validamos que no halla error con el archivo
        if(f==NULL)
        {
            printf("hubo un error");
            exit(1);
        }
        //si no hay error hacemos un while que lo recorra, mientras que no halla llegado al final del archivo !feof
        else
        {
            while(!feof(f))
            {
                 if(tam == i)
                {
                    int x = sizeof(eAuto)*(tam+20);

                    auto1Aux=(eAuto*)realloc(auto1,sizeof(eAuto)*(tam+20));

                    if(auto1Aux==NULL)
                    {

                        printf("%d no hay mas lugar", i);
                        exit(1);
                    }

                        auto1=auto1Aux;
                        tam+=20;

                }
                //cant es la cantidad d variables que lee fscanf
                cant = fscanf(f,"%d, %[^,], %[^,],%[^,],%d\n", &(auto1+i)->id,(auto1+i)->marca,(auto1+i)->modelo, (auto1+i)->color,&(auto1+i)->anio);
                //si cantidad es distinta a la cantidad
                if(cant!=5)
                {
                    if(feof(f))
                    {
                        break;
                    }
                    else
                    {
                        printf("hubo un error");
                        exit(1);
                    }
                }



                printf("%4d %16s %16s %16s  %4d\n",(auto1+i)->id,(auto1+i)->marca,(auto1+i)->modelo,(auto1+i)->color,(auto1+i)->anio);

                i++;
            }

            fclose(f);
        }
    }

    free(auto1);
    return 0;
}

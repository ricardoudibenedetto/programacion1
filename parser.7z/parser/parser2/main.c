#include <stdio.h>
#include <stdlib.h>
/*lectura de archivos mediante parser
 el archivo que leemos es generado por mockaroo*/
int main()
{
     int cant;
    FILE* f;
    char marca[20];
    char modelo[20];
    char color[20];
    int anio;
    int id;
//abrimos el puntero a file en mido de lectura r
    f=fopen("MOCK_DATA.csv","r");
    //validamos que no halla error con el archivo
    if(f==NULL)
    {
        printf("hubo un error");
        exit(1);
    }
    //si no hay error hacemos un while que lo recorra, mientras que no halla llegado al final del archivo !feof
    else
    {
        while(!feof(f))
        {
            //cant es la cantidad d variables que lee fscanf
            cant = fscanf(f,"%d, %[^,], %[^,],%[^,],%d\n", &id,marca,modelo, color,&anio);
            //si cantidad es distinta a la cantidad
            if(cant!=5)
            {
                if(feof(f))
                {
                    break;
                }
                else
                {
                    printf("hubo un error");
                    exit(1);
                }
            }

            printf("%4d %16s %16s %16s  %4d\n",id,marca,modelo,color,anio);

        }
        fclose(f);
    }
    return 0;
}

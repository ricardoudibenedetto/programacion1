#include <stdio.h>
#include <stdlib.h>
void mostrarCadena(char* punteroCadena);
char* getCharX(void);
int main()
{
    char cad[51];
    strcpy(cad,getCharX());
    printf("%s",cad);


    return 0;
}


void mostrarCadena(char* punteroCadena)
{
while(*punteroCadena != '\0')
{
printf("%c",*punteroCadena);

punteroCadena++;
}
}

char* getCharX(void)
{
    char letra[]="abc";
    return letra;
}

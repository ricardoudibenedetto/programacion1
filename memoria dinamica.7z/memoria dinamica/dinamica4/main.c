#include <stdio.h>
#include <stdlib.h>
typedef struct
{
    int legajo;
    char nombre[20];
    float sueldo;

}eEmpleado;
void mostrar(eEmpleado*);
eEmpleado* newEmpleado();
eEmpleado* newEmpleadoParam(int , char*, float);

int main()
{
    eEmpleado* unEmpleado;
    unEmpleado=newEmpleado();
    if(unEmpleado==NULL)
    {
        printf("no se encontro lugar en la memoria");
        system("pause");
        exit(1);
    }
    else
    {
         mostrar(unEmpleado);
    }

    return 0;
}


void mostrar(eEmpleado* emp)
{
   printf("%d %s %.2f", emp->legajo, emp->nombre, emp->sueldo);
}

eEmpleado* newEmpleado()
{
    eEmpleado* p;
    p=(eEmpleado*) malloc(sizeof(eEmpleado));
    if(p!=NULL)
    {
        p->legajo=123;
        strcpy(p->nombre, " pepe ");
        p->sueldo=23.0;
    }
    return p;
}
eEmpleado* newEmpleadoParam(int legajo, char* nombre, float sueldo)
{
     eEmpleado* p;
    p=(eEmpleado*) malloc(sizeof(eEmpleado));
    if(p!=NULL)
    {
        p->legajo=legajo;
        strcpy(p->nombre, nombre);
        p->sueldo=sueldo;
    }
    return p;
}

#include <stdio.h>
#include <stdlib.h>
#define TAM 5
int main()
{
    int* vec;
    int* aux;
    vec =(int*)malloc(TAM*sizeof(int));//calloc(tam,sizeof(int)); igual a malloc pero inicializa todo en 0
    if(vec==NULL)
    {
        printf("\nNo se pudo encontrar memoria\n\n");
        system("pause");
        exit(1);
    }
    for(int i=0;i<TAM;i++)
    {
        printf("ingrese un numero: ");
        scanf("%d", vec+i );
    }
    for(int i=0;i<TAM;i++)
    {
        printf("%d", *(vec+i) );
    }
    printf("\n");
    aux=(int*)realloc(vec ,(TAM+5)*sizeof(int));
    if(aux==NULL)
    {
        printf("no se pudo conseguir memoria\n");
        system("pause");
        exit(1);
    }
    else
    {
        vec=aux;
        for(int i=5;i<TAM+5;i++)
        {
            printf("ingrese un numero: ");
            scanf("%d", vec+i );
        }
        for(int i=0;i<TAM+5;i++)
        {
            printf("%d", *(vec+i) );
        }
    }

    /*para achicar
    vec=(int*)realloc(vec, TAM*sizeof(int));
    for(i=0;i<tam;i++)
    {
        printf("%d", (vec+i));
    }
    */
    free(vec);
    return 0;
}

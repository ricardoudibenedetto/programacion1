#include <stdio.h>
#include <stdlib.h>

int main()
{
    int* pNum;
    pNum= (int*) malloc(sizeof(int));
    if(pNum==NULL)
    {
        printf("\nno se pudo encontrar memoria dinamica, el programa finaliza");
        exit(1);
    }
    printf("ingrese un numero : ");
    scanf("%d", pNum);
    //*pNum=5;

    printf("%d\n\n",*pNum);
    free(pNum);
    return 0;
}

#include <stdio.h>
#include <stdlib.h>
#define TAM 5
int main()
{

    int* vec;
    vec =(int*)malloc(TAM*sizeof(int));//calloc(tam,sizeof(int)); igual a malloc pero inicializa todo en 0
    if(vec==NULL)
    {
        printf("\nNo se pudo encontrar memoria\n\n");
        system("pause");
        exit(1);
    }
    for(int i=0;i<TAM;i++)
    {
        printf("ingrese un numero: ");
        scanf("%d", vec+i );
    }
    for(int i=0;i<TAM;i++)
    {
        printf("%d", *(vec+i) );
    }
    free(vec);
    return 0;
}

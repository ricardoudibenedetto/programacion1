#include <stdio.h>
#include <stdlib.h>
typedef struct
{
    int legajo;
    char nombre[50];
    float sueldo;
    int estado;
}eEmpleado;
eEmpleado* new_empleado();
eEmpleado* new_empleado_param(int,char*,float);
void mostrarEmpleado(eEmpleado* );
void mostrarEmpleados(eEmpleado* vec, int tam);
eEmpleado* new_ArrayEmpleados(int tam);
void inicializarEmpleados(eEmpleado* vec,int tam);
void guardarEmpleados(char *, int tam, char* );
int main()
{
    char nombre[50]="ricardo";
    eEmpleado* pEmpleado;
    pEmpleado=new_empleado_param(124,nombre,6000.24);
    mostrarEmpleados(pEmpleado,10);

    return 0;
}
eEmpleado* new_empleado()
{
    eEmpleado* pEmpleado;
    pEmpleado=(eEmpleado*)malloc(sizeof(pEmpleado));
    if(pEmpleado!=NULL)
    {
        pEmpleado->legajo=0;
        pEmpleado->sueldo=0;
        strcpy(pEmpleado->nombre,"");
        pEmpleado->estado=0;
    }
    return pEmpleado;
}

eEmpleado* new_empleado_param(int legajo,char* nombre,float sueldo)
{
    eEmpleado* pEmpleado;
    pEmpleado=new_empleado();
    if(pEmpleado!=NULL)
    {
        pEmpleado->legajo=legajo;
        pEmpleado->sueldo=sueldo;
        pEmpleado->estado=1;
        strcpy(pEmpleado->nombre,nombre);
    }
    return pEmpleado;
}
void mostrarEmpleado(eEmpleado* vec)
{
    if(vec->estado==1)
    {
            printf("nombre: %s\nlegajo: %d\nsueldo: %.2f\n\n",vec->nombre, vec->legajo, vec->sueldo);
    }
}
void mostrarEmpleados(eEmpleado* vec, int tam)
{
    int i;
    if(vec!=NULL&&tam>0)
    {
            for(i=0;i<tam;i++)
        {
            if((vec+i)->estado==1)
            {
                mostrarEmpleado(vec+i);
            }
        }
    }
    else
    {
        printf("no se puede mostrar los empleados");
    }

}
eEmpleado* new_ArrayEmpleados(int tam)
{

    eEmpleado* vec;
    if(tam>0)
    {
         vec=(eEmpleado*)malloc(sizeof(vec)*tam);
        if(vec!=NULL)
        {
            inicializarEmpleados(vec,tam);
        }
    }


    return vec;
}

void inicializarEmpleados(eEmpleado* vec,int tam)
{
    if(vec!=NULL&&tam>0)
    {
        for(int i=0;i<tam;i++)
        {
            (vec+i)->estado=0;
        }
    }
}

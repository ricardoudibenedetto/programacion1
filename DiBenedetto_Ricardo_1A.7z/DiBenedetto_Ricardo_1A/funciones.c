#include <stdio.h>
#include <stdlib.h>
#include "funciones.h"
#include "entidades.h"
int validarNumero(char mensaje[])
{
    int validar;
    int numero;
    int i;
    long tam=256;
    char val, numeroCadena[tam];
    int tamCadena;
    printf("%s", mensaje);
    fflush(stdin);
    gets(numeroCadena);
    tamCadena=strlen(numeroCadena);
    for(i=0;i<tamCadena;i++)
    {
        if(!isdigit( numeroCadena[i]))
        {
            validar=1;
            break;
        }
    }
        while(validar==1)
        {
            printf("Error ,ingrese un numero : ");
            fflush(stdin);
            gets(numeroCadena);
            tamCadena=strlen(numeroCadena);
            for(i=0;i<tamCadena;i++)
            {
               if(!isdigit( numeroCadena[i]))
                {
                    validar=1;
                    break;
                }else
                {
                    validar=0;
                }
            }
        }
     numero=atoi(numeroCadena);
  return numero;
}


int validarLetras(char cadena[])
{
    int i=0;
    int validar;
    int tamCadena;
    tamCadena=strlen(cadena);
    for(i=0;i<tamCadena;i++)
    {

        if(isdigit(cadena[i]))
        {
            validar=1;
            break;
        }
        else
        {
            validar=0;
        }
    }
return validar;
}




void iniciarEstado(eProducto vec[], int tam)
{
    int i;
    for(i=0;i<tam;i++)
        {
                    vec[i].estado=0;
        }
}

int buscarLibre(eProducto vec[], int tam)
{
   int indice=-1;
   for(int i=0;i<tam;i++)
    {
        if(vec[i].estado==0)
            {
               indice=i;
                break;
            }

    }
     return indice;
}


int buscarPersona(eProducto vec[], int tam, int codigoProducto)
{
    int indice=-1;
    for(int i=0;i<tam;i++)
        {
            if(vec[i].codigoProducto==codigoProducto&&vec[i].estado==1)
                {
             indice=i;
                }
        }
         return indice;
}











void altaProducto(eProducto vec[],int tam)
{
    eProducto nuevaPersona;
    int codigoProducto, esta, indice, largoCadena;
    char nombreAux[300];
    indice=buscarLibre(vec, 20);
    if(indice==-1)
    {
        printf("No hay espacio para almacenar otra persona\n");
    }
    else
    {

            printf("ingrese un nombre: ");
            fflush(stdin);
            scanf("%s",&nombreAux);

           while(validarLargoCadena(nombreAux,49)==1 || validarLetras(nombreAux)==1)
           {
                printf("Error, ingrese un nombre sin numeros y que no exceda los 50 caracteres: ");
                fflush(stdin);
                scanf("%s",&nombreAux);
           }
           strcpy(nuevaPersona.descripcion, nombreAux);

            fflush(stdin);

            nuevaPersona.importe=validarNumeroFlotante("ingrese un importe: ");
            nuevaPersona.cantidadProducto=validarNumero("ingrese la cantidad de productos: ");

            printf("\n1.- Proveedor1 \n2.- Proveedor2 \n3.- proveedor3 \n4.- Proveedor4 \n5.- Proveedor5\nIngrese un sector: ");
            scanf("%d",&nuevaPersona.idProductoProveedor);

            printf("%d",indice);
            nuevaPersona.codigoProducto = indice+1;
            nuevaPersona.estado = 1;

            vec[indice]=nuevaPersona;
            printf("\n carga exitosa!!\n");
            system("pause");

    }
}









void mostrarPersonas(eProducto vec[],int tam)
{
    printf(" nombre\timporte\t\tcantidad \tcodigo\n");
    for(int i=0;i<tam;i++)
        {
            if(vec[i].estado==1)
                {
                    mostrarPersona(vec[i]);
                }
        }
}
void mostrarPersona(eProducto vec)
{
    printf(" %s      %.2f        %d          %d\n",vec.descripcion,vec.importe,vec.cantidadProducto,vec.codigoProducto);
}


void baja(eProducto vec[],int tam, int codigoProducto)
{

     int esta;
     esta=buscarPersona(vec, tam , codigoProducto);
      if(esta==-1)
            {
               printf("\n El numero de DNI no existe.\n");
            }
            else
            {
                vec[esta].estado=0;
                   printf("\n Baja exitosa !\n") ;
            }


}


void ordenaPorNombre(eProducto vec[],int tam)
{
        eProducto aux;
      for(int i=0;i<tam-1;i++)
                {
                    for(int j=i+1;j<tam;j++)
                    {

                       if(vec[i].importe < vec[j].importe)
                             {
                                 aux=vec[i];
                                 vec[i]=vec[j];
                                 vec[j]=aux;
                             }

                        if(vec[i].importe==vec[j].importe)
                        {

                                 if(strcmp(vec[i].descripcion,vec[j].descripcion)>0)
                                {
                                strcpy( aux.descripcion,vec[i].descripcion);
                                strcpy( vec[i].descripcion,vec[j].descripcion);
                                strcpy( vec[i].descripcion,aux.descripcion);
                                }


                         }


                    }
                }
}

int pedirInt(char mensaje[])
{
    int aux;
    printf("%s",mensaje);
    scanf("%d",&aux);
    return aux;
}

float validarNumeroFlotante(char mensaje[])
{

    int validar;
    float numero;
    int i;
    long tam=256;
    char val, numeroCadena[tam];
    int tamCadena;
    printf("%s", mensaje);
    fflush(stdin);
    gets(numeroCadena);
    tamCadena=strlen(numeroCadena);
    for(i=0;i<tamCadena;i++)
    {
        if(isalpha( numeroCadena[i]))
        {
            validar=1;
            break;
        }
    }
        while(validar==1)
        {
            printf("Error ,ingrese un numero : ");
            fflush(stdin);
            gets(numeroCadena);
            tamCadena=strlen(numeroCadena);
            for(i=0;i<tamCadena;i++)
            {
               if(isalpha( numeroCadena[i]))
                {
                    validar=1;
                    break;
                }else
                {
                    validar=0;
                }
            }
        }
     numero=atof(numeroCadena);
  return numero;
}


void modifica(eProducto vec[], int tam){
    int legajo;
    int esta;
    char confirma;
    int salir = 0;
    int codigo;
    float nuevoImporte;
    int nuevaCantidad;
    char nombreAux[300];
    system("cls");
    printf("---Modifica Producto---\n\n");

   printf("Ingrese codigo: ");
        scanf("%d", &codigo);

        esta = buscarPersona(vec, tam, codigo);

        if(esta == -1)
        {
            printf("\nEl codigo %d no se encuentra en el sistema\n\n", codigo);

        }
        else{

                mostrarPersona(vec[esta]);

        do{
            printf("\nConfirma baja? [s|n]: ");
            fflush(stdin);
            scanf("%c", &confirma);
            confirma = tolower(confirma);
        }while(confirma != 's' && confirma != 'n');

        if(confirma == 's'){
            do{
                switch(menuModifica()){
                    case 1:

                         printf("ingrese un nombre: ");
                        fflush(stdin);
                        scanf("%s",&nombreAux);

                       while(validarLargoCadena(nombreAux,49)==1 || validarLetras(nombreAux)==1)
                       {
                            printf("Error, ingrese un nombre sin numeros y que no exceda los 50 caracteres: ");
                            fflush(stdin);
                            scanf("%s",&nombreAux);
                       }
                        strcpy(vec[esta].descripcion, nombreAux);

                        break;
                    case 2:
                        nuevoImporte=validarNumeroFlotante("ingrese un nuevo importe");
                        vec[esta].importe=nuevoImporte;
                        break;
                    case 3:
                        nuevaCantidad=validarNumero("ingrese nueva cantidad");
                        vec[esta].cantidadProducto=nuevaCantidad;
                        break;
                    case 4:
                        salir = 1;
                        break;
                }

            }while(salir != 1);
            printf("\nSe ha realizado la modificacion\n\n");
        }
        else{
            printf("\nSe ha cancelado la modificacion\n\n");
        }

        }
        system("pause");
}

int menuModifica()
{
    int opcion;

    system("cls");
    printf("---Modificar productos--\n\n");
    printf("1-Nombre\n");
    printf("2-importe\n");
    printf("3-cantidad del producto\n");
    printf("4-salir\n");

    printf("\nIndique opcion: ");
    scanf("%d", &opcion);

    return opcion;
}
/*
void informar(eProducto producto[],int tam)
{
    int contador=0;
    int superoPromedio=0;
    int noSuperoPromedio=0;
    int productosMas10=0;
    int productosMenos10=0;
    int i;
    int val=0;
    int mayor;

    float promedio=0;
    float sumaImportes=0;
    int sumastock=0;
    for(i=0;i<tam;i++)
    {
        if(producto[i].estado==1)
            {
                sumaImportes=sumaImportes+producto[i].importe;
                sumastock=sumastock+producto[i].cantidadProducto;
            }
    }

    promedio=sumaImportes/sumastock;
 for(int i=0;i<tam;i++)
                {
               if(producto[i].importe>promedio && producto[i].estado==1)
               {
                   superoPromedio++;
               }

               if(producto[i].importe<promedio && producto[i].estado==1)
                {
                    noSuperoPromedio++;
                }
                if(producto[i].cantidadProducto<11 && producto[i].estado==1)
                {
                    productosMenos10++;
                }
                if(producto[i].cantidadProducto>9 && producto[i].estado==1)
                {
                    productosMas10++;
                }

                }
    printf("suma de los stock : %d \n", sumastock);
    printf("suma de los importes : %.2f \n", sumaImportes);
    printf("el promedio es : %.2f \n", promedio);
    printf("supero promedio : %d \nno supero promedio : %d\n", superoPromedio, noSuperoPromedio);
    printf("cantidad de productos menores a 10 : %d \ncantidad de productos mayores a 10 : %d\n", productosMenos10, productosMas10);
    system("pause");
}
*/

int validarLargoCadena(char cadena[],int  LargoMaximo)
{
            int largoCadena;
            largoCadena=strlen(cadena);
            if(largoCadena<LargoMaximo)
            {
               return 0;
            }
            else
            {
                return 1;

            }
}


void informarA(eProducto producto[],int tam)
{
     int contador=0;
    int superoPromedio=0;
    int noSuperoPromedio=0;
    int productosMas10=0;
    int productosMenos10=0;
    int i;
    int val=0;
    int mayor;

    float promedio=0;
    float sumaImportes=0;
    int sumastock=0;
    for(i=0;i<tam;i++)
    {
        if(producto[i].estado==1)
            {
                sumaImportes=sumaImportes+producto[i].importe;
                sumastock=sumastock+producto[i].cantidadProducto;
            }
    }

    promedio=sumaImportes/sumastock;
 for(int i=0;i<tam;i++)
                {
               if(producto[i].importe>promedio && producto[i].estado==1)
               {
                   superoPromedio++;
               }

               if(producto[i].importe<promedio && producto[i].estado==1)
                {
                    noSuperoPromedio++;
                }
                if(producto[i].cantidadProducto<11 && producto[i].estado==1)
                {
                    productosMenos10++;
                }
                if(producto[i].cantidadProducto>9 && producto[i].estado==1)
                {
                    productosMas10++;
                }

                }
    printf("suma de los stock : %d \n", sumastock);
    printf("suma de los importes : %.2f \n", sumaImportes);
    printf("el promedio es : %.2f \n", promedio);
    printf("supero promedio : %d \n", superoPromedio);

    system("pause");
}
void informarB(eProducto producto[],int tam)
{
     int contador=0;
    int superoPromedio=0;
    int noSuperoPromedio=0;
    int productosMas10=0;
    int productosMenos10=0;
    int i;
    int val=0;
    int mayor;

    float promedio=0;
    float sumaImportes=0;
    int sumastock=0;
    for(i=0;i<tam;i++)
    {
        if(producto[i].estado==1)
            {
                sumaImportes=sumaImportes+producto[i].importe;
                sumastock=sumastock+producto[i].cantidadProducto;
            }
    }

    promedio=sumaImportes/sumastock;
 for(int i=0;i<tam;i++)
                {
               if(producto[i].importe>promedio && producto[i].estado==1)
               {
                   superoPromedio++;
               }

               if(producto[i].importe<promedio && producto[i].estado==1)
                {
                    noSuperoPromedio++;
                }
                if(producto[i].cantidadProducto<11 && producto[i].estado==1)
                {
                    productosMenos10++;
                }
                if(producto[i].cantidadProducto>9 && producto[i].estado==1)
                {
                    productosMas10++;
                }

                }
    printf("suma de los stock : %d \n", sumastock);
    printf("suma de los importes : %.2f \n", sumaImportes);
    printf("el promedio es : %.2f \n", promedio);
    printf("No supero promedio : %d \n", noSuperoPromedio);

    system("pause");
}


void informarC(eProducto producto[],int tam)
{
    int contador=0;
    int superoPromedio=0;
    int noSuperoPromedio=0;
    int productosMas10=0;
    int productosMenos10=0;
    int i;
    int val=0;
    int mayor;

    float promedio=0;
    float sumaImportes=0;
    int sumastock=0;
    for(i=0;i<tam;i++)
    {
        if(producto[i].estado==1)
            {
                sumaImportes=sumaImportes+producto[i].importe;
                sumastock=sumastock+producto[i].cantidadProducto;
            }
    }

    promedio=sumaImportes/sumastock;
 for(int i=0;i<tam;i++)
                {
               if(producto[i].importe>promedio && producto[i].estado==1)
               {
                   superoPromedio++;
               }

               if(producto[i].importe<promedio && producto[i].estado==1)
                {
                    noSuperoPromedio++;
                }
                if(producto[i].cantidadProducto<11 && producto[i].estado==1)
                {
                    productosMenos10++;
                }
                if(producto[i].cantidadProducto>9 && producto[i].estado==1)
                {
                    productosMas10++;
                }

                }

    printf("cantidad de productos menores a 10 : %d \n", productosMenos10);
    system("pause");
}
void informarD(eProducto producto[],int tam)
{
    int contador=0;
    int superoPromedio=0;
    int noSuperoPromedio=0;
    int productosMas10=0;
    int productosMenos10=0;
    int i;
    int val=0;
    int mayor;

    float promedio=0;
    float sumaImportes=0;
    int sumastock=0;
    for(i=0;i<tam;i++)
    {
        if(producto[i].estado==1)
            {
                sumaImportes=sumaImportes+producto[i].importe;
                sumastock=sumastock+producto[i].cantidadProducto;
            }
    }

    promedio=sumaImportes/sumastock;
 for(int i=0;i<tam;i++)
                {
               if(producto[i].importe>promedio && producto[i].estado==1)
               {
                   superoPromedio++;
               }

               if(producto[i].importe<promedio && producto[i].estado==1)
                {
                    noSuperoPromedio++;
                }
                if(producto[i].cantidadProducto<11 && producto[i].estado==1)
                {
                    productosMenos10++;
                }
                if(producto[i].cantidadProducto>9 && producto[i].estado==1)
                {
                    productosMas10++;
                }

                }

    printf("cantidad de productos mayor a 10 : %d \n", productosMas10);
    system("pause");
}

int menuListar()
{
    int opcion;

    system("cls");
    printf("1-Total e importes y cuantos productos superaron ese promedio \n");
    printf("2-Total e importes y cuantos productos no superaron ese promedio \n");
    printf("3-cantidad de producto stock mayor a 10\n");
    printf("4-cantidad de producto stock menores a 10\n");
    printf("5-salir\n");

    printf("\nIndique opcion: ");
    scanf("%d", &opcion);

    return opcion;
}

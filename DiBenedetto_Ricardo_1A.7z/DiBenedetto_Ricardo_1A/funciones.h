
#ifndef FUNCIONES_H_INCLUDED
#define FUNCIONES_H_INCLUDED
#include "entidades.h"
typedef struct {

    char descripcion[50];
    int cantidadProducto;
    int estado;
    float importe;
    int codigoProducto;
    int idProductoProveedor;

}eProducto;

typedef struct {

    char descripcion[50];
    int estado;
    int idProveedor

}eProveedor;
void informarC(eProducto producto[],int tam);
void informarD(eProducto producto[],int tam);
void informarB(eProducto producto[],int tam);
void informarA(eProducto producto[],int tam);
float validarNumeroFlotante(char mensaje[]);
int buscarPorDni(eProducto lista[], int codigoProducto);
int validarLetras(char cadena[]);
int validarNumero(char mensaje[]);
void iniciarEstado(eProducto vec[], int tam);
int buscarLibre(eProducto vec[],int tam);
int buscarPersona(eProducto vec[], int tam, int codigoProducto);
void altaProducto(eProducto vec[],int tam);
void mostrarPersonas(eProducto vec[],int tam);
void mostrarPersona(eProducto vec);
void baja(eProducto vec[],int tam, int codigoProducto);
void ordenaPorNombre(eProducto vec[],int tam);
void informar(eProducto persona[], int tam);
int validarLargoCadena(char cadena[], int largoMaximo);
int pedirInt(char mensaje[]);
void modifica(eProducto vec[], int tam);
int menuModifica();
int menuListar();
#endif // FUNCIONES_H_INCLUDED



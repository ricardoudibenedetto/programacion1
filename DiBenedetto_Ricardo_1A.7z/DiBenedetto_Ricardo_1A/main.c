#include <stdio.h>
#include <stdlib.h>
#include "funciones.h"
#include "entidades.h"
int main()
{
    char seguir='s';
    int opcion=0;
    int tam=20;
    int codigoProducto;
    eProducto persona[20];
    eProducto personaAux;
    iniciarEstado(persona,tam);
     int respuesta=0;
    while(seguir=='s')
    {
        system("cls");
        printf("1- Agregar persona\n");
        printf("2- Borrar persona\n");
        printf("3- Imprimir lista ordenada por  nombre\n");
        printf("4- Informar\n");
        printf("5- modificar\n");
        printf("6- Salir\n");

        scanf("%d",&opcion);
        switch(opcion)
        {
            case 1:
                altaProducto(persona, 20);
                break;
            case 2:
                codigoProducto=validarNumero("ingrese codigo de producto: ");
                baja(persona,20,codigoProducto);
                system("pause");
                break;
            case 3:
               // ordenaPorNombre(persona,20);
                mostrarPersonas(persona, 20);
                system("pause");
                break;
            case 4:
                            while(respuesta!=-1){
                            printf("\n\n");
                            respuesta=menuListar();
                              switch(respuesta)
                            {
                        case 1:
                            informarA(persona,20);
                            break;
                        case 2:
                           informarB(persona,20);
                            break;
                        case 3:
                           informarC(persona,20);
                            break;
                        case 4:
                            informarD(persona,20);
                            break;
                        case 5:
                            respuesta=-1;

                            break;
                             default:
                            printf("opcion incorrecta\n");
                            system("pause");
                            break;
                            }
                            }
                break;
            case 5:
                modifica(persona,20);
                break;
            case 6:
                seguir = 'n';
                break;
            default:
                printf("opcion incorrecta\n");
                system("pause");
                break;
        }
    }
    return 0;
}
